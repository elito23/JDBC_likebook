create definer = root@localhost view booksbyemilywilson as
select `b`.`id`            AS `id`,
       `b`.`ISBN`          AS `ISBN`,
       `b`.`title`         AS `title`,
       `b`.`price`         AS `price`,
       `b`.`category`      AS `category`,
       `b`.`publisher_id`  AS `publisher_id`,
       `b`.`maintained_by` AS `maintained_by`,
       `b`.`author_id`     AS `author_id`
from ((`2024_tu_lab1`.`book` `b` join `2024_tu_lab1`.`book_reader` `br`
       on ((`br`.`book_id` = `b`.`id`))) join `2024_tu_lab1`.`reader` `r` on ((`r`.`id` = `br`.`reader_id`)))
where ((`r`.`first_name` = 'Emily') and (`r`.`last_name` = 'Wilson'));

